<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<style type="text/css">
a[name="tambahdata"] {
  background: #424330; 
  color: #fff;
}

a[name="tambahdata"]:hover {
    background: #1D1D13;
    color: #fff;
}

thead {
    background: #424330; 
    color: #fff;
}
</style>

<div class="row">
    <div class="col-sm-12 col-md-10">
        <h4 class="mb-0"><i class="fa fa-share"></i> Data Pembelian Barang</h4>
    </div>
    <div class="col-sm-12 col-md-2">
        <a href="<?= site_url('tambah_pembelian'); ?>" name="tambahdata" class="btn btn-sm btn-block">Tambah Data</a>
    </div>
</div>
<hr class="mt-0" />
<?php
//tampilkan pesan success
if ($this->session->flashdata('success')) {
    echo '<div class="alert alert-success" role="alert">
    ' . $this->session->flashdata('success') . '
  </div>';
}

//tampilkan pesan error
if ($this->session->flashdata('error')) {
    echo '<div class="alert alert-danger" role="alert">
    ' . $this->session->flashdata('error') . '
  </div>';
}
?>
<div class="table-responsive">
    <table class="table table-sm table-hover table-striped" id="tables">
        <thead class="thead">
            <tr>
                <th scope="col">#</th>
                <th scope="col">ID Pembelian</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Supplier</th>
                <th scope="col">Jumlah Jenis</th>
                <th scope="col">Total Harga Beli</th>
                <th scope="col">Petugas</th>
                <th scope="col">Opsi</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>